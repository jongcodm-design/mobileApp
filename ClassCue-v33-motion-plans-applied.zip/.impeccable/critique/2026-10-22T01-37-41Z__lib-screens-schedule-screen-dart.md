---
target: lib/screens/schedule_screen.dart
total_score: 29
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 0
target_identity: "file:C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\screens\\schedule_screen.dart"
target_fingerprint: "sha256:f257e63f6c0080733af1a0c7d684abaaf2dc1d5327602ac4954f2cdf6af993aa"
target_path: "C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\screens\\schedule_screen.dart"
timestamp: 2026-10-22T01-37-41Z
slug: lib-screens-schedule-screen-dart
---
Method: design review only (detector not applicable, native platform)

# Weekly Schedule Section Critique

**Target:** lib/screens/schedule_screen.dart  
**Mode:** Operate — scan and browse a recurring weekly timetable.

## Design Health Score

| # | Heuristic | Score | Key issue |
|---|---|---:|---|
| 1 | Visibility of System Status | 3 | Selected day, today, class dots, loading, and error states are visible; dots stop distinguishing counts above three. |
| 2 | Match System / Real World | 3 | Weekday labels are familiar, but calendar dates appear without a way to browse other weeks. |
| 3 | User Control and Freedom | 3 | Users can select a day, refresh, and open class actions; week navigation is unavailable. |
| 4 | Consistency and Standards | 3 | Class cards and surfaces match the app; the seven-day selector is a bespoke compact control. |
| 5 | Error Prevention | 3 | Empty and load-error states are handled; the narrow day targets can cause mis-taps. |
| 6 | Recognition Rather Than Recall | 3 | The strip identifies weekdays and today, but the selected weekday is not named in the class-list heading. |
| 7 | Flexibility and Efficiency | 2 | Day switching is fast, but the selector only represents the current calendar week. |
| 8 | Aesthetic and Minimalist Design | 3 | The screen is clean, though the summary and day strip compete slightly for top-level attention. |
| 9 | Error Recovery | 3 | Refresh, retry, and class-delete undo are available. |
| 10 | Help and Documentation | 3 | The empty state gives a clear route to add a class; other interactions rely on familiar patterns. |
| **Total** | | **29/40** | **Good — 72.5%** |

## Design Specificity Verdict

**LLM assessment:** The screen is clearly a weekly class timetable: day selection, class counts, chronological cards, and live/upcoming status fit the task. The overall language is consistent with ClassCue. The main opportunity is to clarify whether this is a recurring weekday schedule or a date-based calendar, then make the selected day easier to track while scrolling.

**Deterministic scan:** Not applicable (native Flutter platform).

**Visual overlays:** Not applicable (native Flutter platform).

## Overall Impression

The screen has a strong, simple structure: summary, weekday strip, and selected-day classes. The selection states and empty-state guidance are useful. The biggest opportunity is making day selection easier to tap and keeping the selected-day context visible once the user scrolls into a long list.

## What’s Working

- The selected day uses a filled marker and today uses an outline, so the two states are distinct.
- Weekday tiles announce the full date, today state, and class count to screen readers.
- Classes are sorted by start time, and status coloring is limited to today’s classes.

## Cognitive Load Assessment

**Moderate: 2 of 8 checklist failures.**

- **Minimal choices:** The strip presents seven day choices at once. That matches the week task, but it exceeds the four-choice comfort target.
- **Working memory:** The selected weekday is visible only in the strip; after scrolling past it, the heading says only “Classes” and cards do not repeat the day.

Grouping, hierarchy, and the empty-day guidance are otherwise clear.

## Priority Issues

### 1. [P2] Day tiles can fall below the 48dp touch-target guideline

**Location:** schedule_screen.dart:202

Seven tiles divide the available width equally inside 20dp side padding. On a 320dp-wide phone, each tile is about 40dp wide; even at 360dp, it is under 46dp. This makes day switching harder for users with motor impairments and increases mis-taps.

**Fix:** Give each day a 48dp minimum hit area and allow the strip to scroll horizontally on narrow screens, or use a day selector that preserves seven-day context without compressing touch targets.

**Suggested command:** $impeccable adapt

### 2. [P2] The selected day disappears from context while scrolling

**Location:** schedule_screen.dart:226

The list heading is only “Classes,” and class cards omit the day. Once the selector scrolls off-screen, a user browsing a long day list can lose which weekday they are viewing.

**Fix:** Name the selected weekday in the list heading and keep that heading pinned while the class list scrolls.

**Suggested command:** $impeccable layout

### 3. [P2] Calendar dates appear without week navigation

**Location:** schedule_screen.dart:167

The strip shows day-of-month numbers from the current Monday-to-Sunday week, but there are no previous/next-week controls. Because ClassCue stores repeating weekday schedules, the dates can imply a date-based calendar that users cannot browse.

**Fix:** Decide the model: for a repeating weekly timetable, use weekday labels with a clear Today marker; if the dates are intentional, add previous/next-week navigation.

**Suggested command:** $impeccable clarify

## Persona Red Flags

**Jordan — First-Timer:** The list heading says “Classes,” not “Tuesday’s classes.” Jordan may lose the selected-day context after scrolling and need to return to the strip to confirm.

**Sam — Accessibility-Dependent User:** The full semantic label on each day is strong. At narrow phone widths, however, each day’s hit area can be around 40dp, below Material’s 48dp target.

**Casey — Distracted Mobile User:** The selector is above the scrolling list and the selected day is not repeated in the list heading. An interruption or long scroll can make Casey forget which day is active.

## Minor Observations

- Each day shows at most three dots; a day with three classes looks the same as one with many more. Consider a numeric count or “3+”.
- The summary line and class dots both provide schedule-volume information, though the summary adds useful week-level context.
- Dates in the strip are useful for locating today, but they need a clear role if the timetable is recurring.

## Questions to Consider

- Is this section meant to browse a recurring weekly pattern or specific calendar weeks?
- Should the day strip preserve all seven options at once, or prioritize larger touch targets on compact phones?
