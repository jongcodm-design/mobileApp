---
target: lib/features/schedule_import/import_schedule_screen.dart
total_score: 32
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 1
target_identity: "file:C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\features\\schedule_import\\import_schedule_screen.dart"
target_fingerprint: "sha256:a67a30c76d4677e257ab9509af3fdc8346249ea8cc0b3281fe510f0a78a14274"
target_path: "C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\features\\schedule_import\\import_schedule_screen.dart"
timestamp: 2026-10-22T01-25-50Z
slug: hedule-import-import-schedule-screen-dart-470e3535
---
Method: design review only (detector not applicable, native platform)

# Import Schedule Screen Critique

**Target:** lib/features/schedule_import/import_schedule_screen.dart  
**Mode:** Operate — import and review a timetable.

## Design Health Score

| # | Heuristic | Score | Key issue |
|---|---|---:|---|
| 1 | Visibility of System Status | 4 | Scan progress, cancellation, errors, and completion are communicated. |
| 2 | Match System / Real World | 4 | Import, review, class, room, and replacement language is familiar. |
| 3 | User Control and Freedom | 3 | Users can cancel scanning, switch to manual entry, edit drafts, and cancel review; deleting a draft has no undo. |
| 4 | Consistency and Standards | 3 | Material patterns and ClassCue surfaces are consistent; draft editing relies on a less visible whole-card tap. |
| 5 | Error Prevention | 3 | Conflicts and replacements receive checks, but long warning sets can be acknowledged without inspection. |
| 6 | Recognition Rather Than Recall | 3 | File guidance and issue badges are visible; editing a draft is not visually explicit. |
| 7 | Flexibility and Efficiency | 3 | OCR and manual entry coexist, with add, replace-all, and replace-selected options. |
| 8 | Aesthetic and Minimalist Design | 3 | The hierarchy is sound, though the review screen accumulates banners, cards, choices, and repeated reassurance. |
| 9 | Error Recovery | 3 | Scan errors offer retry/manual paths; some readiness and warning states need clearer recovery cues. |
| 10 | Help and Documentation | 3 | Inline file and photo guidance helps, but the review actions could explain themselves better. |
| **Total** | | **32/40** | **Good — 80%** |

## Design Specificity Verdict

**LLM assessment:** The screen is grounded in timetable import: it explains supported files, offline processing, OCR review, conflicts, and schedule replacement. Its monochrome Material styling fits ClassCue. The main opportunity is to make correction and import readiness clearer throughout the long review step.

**Deterministic scan:** Not applicable (native Flutter platform).

**Visual overlays:** Not applicable (native Flutter platform).

## Overall Impression

The flow builds trust by keeping OCR results reviewable and requiring confirmation for destructive replacement. The largest weakness is the warning path: the interface can hide warning details while still offering one acknowledgement action, and the pinned Import button does not explain its disabled state.

## What’s Working

- The source screen gives supported formats, a file-size limit, an offline cue, a manual-entry alternative, and photo-quality guidance before scanning.
- Scanning reports progress and supports cancellation; users have a manual fallback when recognition fails.
- Draft cards show class details and issue states, and replacement operations are confirmed before saved classes change.

## Cognitive Load Assessment

**Moderate: 3 of 8 checklist failures.**

- **One decision at a time:** review warnings, import strategy, and class corrections share one long screen.
- **Minimal choices:** Replace-selected can expose every saved class as a checkbox; schedules with more than four classes create a long choice set.
- **Working memory:** review warnings sit above the draft list, while the pinned Import button gives no specific reason when disabled.

The three import strategies are understandable and remain within four top-level choices. The selected-class checklist is the point where the choice count can grow.

## Priority Issues

### 1. [P1] Acknowledgement can hide unreviewed scan warnings

**Location:** import_schedule_screen.dart:1145

The banner renders only the first 12 warnings, then says how many remain. “Acknowledge and continue” clears the entire warning list. Page-specific PDF warnings can contain important information about pages that were skipped or mapped unreliably, so users may proceed without seeing those details. The original file preview helps compare the timetable but does not reveal the hidden warning text.

**Fix:** Show the complete warning list in an expandable, scrollable section and make acknowledgement explicitly apply to all listed warnings. Keep the hidden count visible until the user opens the full list.

**Suggested command:** $impeccable harden

### 2. [P2] The pinned Import button does not explain why it is disabled

**Location:** import_schedule_screen.dart:1012 and 1246

Import is disabled for several reasons: unresolved warnings, class issues, or an empty replacement selection. The pinned footer always says conflicts are checked again, which does not identify the current blocker. On a long review, the explanatory banner may be far above the user’s current position.

**Fix:** Show a concise, live reason next to the pinned action, such as “Fix 2 flagged classes” or “Choose classes to replace.” When the action is ready, switch back to the conflict-check reassurance.

**Suggested command:** $impeccable clarify

### 3. [P2] Draft cards do not clearly advertise editing

**Location:** import_review_widgets.dart:483

The whole draft card opens the editor, but the only visible trailing action is Delete. A first-time user may not know the class details are editable, even though correcting OCR output is central to this screen.

**Fix:** Add a visible edit affordance or a short “Tap to edit” cue, while keeping Delete clearly separate.

**Suggested command:** $impeccable clarify

### 4. [P2] Replace-selected becomes a long, unfiltered checklist

**Location:** import_schedule_screen.dart:1448

Choosing “Choose classes to replace” reveals every saved class in a single checkbox list. With a larger schedule, users must scan and remember many similar rows to select the intended classes.

**Fix:** Add search or day grouping, and keep the selected count and removal impact visible while scrolling.

**Suggested command:** $impeccable adapt

## Persona Red Flags

**Jordan — First-Timer:** The review copy says to check details, but the class card has no visible edit cue. Jordan may inspect the list and miss that tapping a row opens the correction form.

**Sam — Accessibility-Dependent User:** The blocking banner is a live region, which is helpful. The disabled Import button still needs a nearby reason so the status is understandable without navigating back through the entire list.

**Casey — Distracted Mobile User:** The sticky footer is easy to reach, but long warnings and replacement checklists require substantial scrolling. When the button is disabled, Casey has to remember an earlier message or scroll back to find the cause.

## Minor Observations

- “Works offline” and the closing note that data stays on-device and needs no internet repeat some reassurance.
- The success card and success notification both repeat the completion message.
- Import-mode choices appear before scan warnings, so users encounter update strategy before seeing all scan caveats.

## Questions to Consider

- Should acknowledgement require opening the complete warning list, or should the full list simply stay expanded by default?
- For Replace-selected, would day grouping be more useful than search for the schedules your users typically import?
