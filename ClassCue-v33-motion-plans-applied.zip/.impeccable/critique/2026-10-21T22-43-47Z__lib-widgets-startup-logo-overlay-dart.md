---
target: features, models, screens, services, theme, utils, widgets; startup_logo_overlay.dart
total_score: 28
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 0
target_identity: "file:C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\widgets\\startup_logo_overlay.dart"
target_fingerprint: "sha256:bfb1779645ffcc10a07a7021a984724510655a5674187e87ff09bdabbdecdb78"
target_path: "C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\widgets\\startup_logo_overlay.dart"
timestamp: 2026-10-21T22-43-47Z
slug: lib-widgets-startup-logo-overlay-dart
---
Method: design review only (detector not applicable, native platform)

# ClassCue design critique

Scope: requested feature, model, screen, service, theme, utility, and widget areas, with focus on [`StartupLogoOverlay`](../../lib/widgets/startup_logo_overlay.dart). Review is based on source; no Android/iOS rendered session was available.

## Design Health Score

| # | Heuristic | Score | Key Issue |
|---|---|---:|---|
| 1 | Visibility of System Status | 3/4 | Scan and loading states are modeled; the fixed startup cover obscures readiness. |
| 2 | Match System / Real World | 3/4 | Class/day/room language is clear; “Low OCR score” and Professor/Instructor naming could be plainer and consistent. |
| 3 | User Control and Freedom | 3/4 | Skip, cancel, edit, and undo are present; startup cover blocks taps briefly. |
| 4 | Consistency and Standards | 3/4 | Shared tokens and components help; notification placement differs from the documented top-toast pattern. |
| 5 | Error Prevention | 3/4 | Required-field, overlap, import, and backup safeguards are strong; OCR warnings can be acknowledged without proving the source was checked. |
| 6 | Recognition Rather Than Recall | 3/4 | Tabs and actions are labeled; first-run Today relies on the global plus menu instead of in-context actions. |
| 7 | Flexibility and Efficiency | 2/4 | Manual/import entry and undo help; schedule search and batch editing are absent. |
| 8 | Aesthetic and Minimalist Design | 3/4 | Monochrome surfaces and a reserved live accent make a focused hierarchy; import review is dense. |
| 9 | Error Recovery | 3/4 | Retry, undo, retained form values, and atomic writes support recovery. |
| 10 | Help and Documentation | 2/4 | Onboarding can be replayed, but contextual help is limited. |
| **Total** | | **28/40** | **Good — a solid foundation with a few focused usability fixes.** |

## Design Specificity Verdict

**LLM assessment:** Product-specific. Today’s next-class hero, the weekly day strip, local timetable scanning, explicit room/OCR uncertainty, and device-local backup give this app a clear identity. The restrained neutral palette with a live-only accent supports glanceable schedule use. The main mismatch is between some documented interaction promises and the current source.

**Deterministic scan:** Not applicable (native platform).

## Overall Impression

The app understands its core job: show what is next, maintain the week, and make schedule import safer through review. The biggest opportunity is making first-run action unmistakable, then reducing friction in the startup and import-review moments.

## What’s Working

- The Today screen links the hero to the matching class row and distinguishes upcoming, live, and finished classes without adding status color everywhere.
- Import communicates that processing is offline, exposes the original source, marks uncertain rooms/names, allows manual corrections, and checks conflicts before saving.
- Domain rules, backup decoding, reminder scheduling, and reusable presentation widgets are separated into understandable layers; shared theme tokens keep the visual language coherent.

## Priority Issues

### 1. [P2] First-run Today repeats the prompt but has no in-context actions

The empty hero says to add a timetable and the empty state repeats “Add your first class or import a weekly schedule,” but that state supplies no buttons. The bottom plus menu is the only action path, so first-time users must infer that the icon opens both Add and Import. See [`home_screen.dart`](../../lib/screens/home_screen.dart) and the optional `actions` API in [`empty_state_card.dart`](../../lib/widgets/empty_state_card.dart).

**Fix:** Put labeled “Add a class” and “Import a timetable” actions in the no-schedule empty state, and remove one of the repeated prompts. Keep the generic plus menu for other screens.

**Suggested command:** `$impeccable onboard`

### 2. [P2] The global startup overlay blocks a ready screen for a fixed 700 ms

[`StartupLogoOverlay`](../../lib/widgets/startup_logo_overlay.dart) puts an opaque layer above the app and removes it on a timer. It does not wait for readiness, fade out, or provide a way to continue; `MaterialApp.builder` applies it across the app. When the first screen is already ready, taps still do nothing; when it is not, the user sees a loading state after the cover disappears.

**Fix:** Prefer the platform launch screen. If an in-app transition is needed, tie it to actual readiness, respect reduced motion, and avoid covering an already usable screen.

**Suggested command:** `$impeccable animate`

### 3. [P2] Import review puts routine review and replacement decisions in one long surface

When saved classes exist, the review screen shows Add, Replace entire schedule, and Choose classes to replace alongside scan warnings and row-level flags. Add is recommended and destructive replacement is confirmed, but users who only want to append still have to scan past advanced choices. Warning summaries and row badges also repeat some of the same review work. See [`import_schedule_screen.dart`](../../lib/features/schedule_import/import_schedule_screen.dart).

**Fix:** Keep Add as the clear primary path; move replacement modes behind a secondary “Change saved classes” disclosure. Keep one concise summary of issues and retain precise row-level flags and destructive confirmation.

**Suggested command:** `$impeccable distill`

### 4. [P2] The seven-day selector can fall below a comfortable touch width

The week strip divides the available width evenly across seven tiles. On a 320 dp screen, after 20 dp side insets, each tile is about 40 dp wide. Its full `InkWell` is that width, below the usual 44–48 dp mobile target. See [`schedule_screen.dart`](../../lib/screens/schedule_screen.dart).

**Fix:** Give each day a minimum 44–48 dp target, using horizontal scrolling or a denser visual tile inside a larger hit area on the narrowest devices.

**Suggested command:** `$impeccable adapt`

## Persona Red Flags

- **Jordan, first-timer:** After skipping onboarding, the Today empty state explains both ways to start but has no labeled action there. The plus affordance is available, but its Add/Import choices are hidden until tapped.
- **Casey, distracted mobile user:** The fixed overlay absorbs the first tap for 700 ms. The week strip’s narrowest cells are about 40 dp wide on a 320 dp device.
- **Sam, accessibility-dependent user:** Week tiles and class rows have explicit semantic labels and selected/status information, which is a good base. The narrow touch width remains a motor-accessibility concern; TalkBack focus order and dynamic scan announcements need device review.

## Minor Observations

- The shared feedback helper uses a floating `SnackBar`, which appears at the bottom, while the README describes a top toast. Pick one placement contract and align the docs and implementation. See [`app_notification.dart`](../../lib/widgets/app_notification.dart).
- The source defines three onboarding pages, while the README says four. Align the count. See [`onboarding_screen.dart`](../../lib/screens/onboarding_screen.dart).
- `ClassItem.professor` is a required string that stores “Not specified” as a sentinel. The UI correctly hides it, but an optional model value or one display mapper would avoid repeating sentinel checks. See [`class_item.dart`](../../lib/models/class_item.dart).
- The live accent, dark/light schemes, and layout tokens are coherent in source; contrast, text scaling, and safe-area behavior still need Android/iOS screenshot review.

## Questions to Consider

- Should the first-use screen prioritize Add a class, or present Add and Import as equal actions?
- Should replacement modes stay visible during import, or appear only when the user chooses to change saved classes?
