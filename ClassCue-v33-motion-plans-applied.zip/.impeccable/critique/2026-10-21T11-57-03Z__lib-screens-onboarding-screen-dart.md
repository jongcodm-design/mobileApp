---
target: ClassCue onboarding
total_score: 33
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 0
target_identity: "file:C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\screens\\onboarding_screen.dart"
target_fingerprint: "sha256:bb37e8e2948fcbe03cea0c2f04eb690b7ef10ac9047d4e4e824c5597157ee6d9"
target_path: "C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\screens\\onboarding_screen.dart"
timestamp: 2026-10-21T11-57-03Z
slug: lib-screens-onboarding-screen-dart
closed: true
---
Method: design review only (detector not applicable, native platform)

## Design Health Score

| # | Heuristic | Score | Key Issue |
|---|-----------|-------|-----------|
| 1 | Visibility of System Status | 3/4 | Progress is shown with dots, but the page count is only announced to screen readers. |
| 2 | Match with Real World | 4/4 | Today, week, timetable, reminders, and backups map to student needs. |
| 3 | User Control and Freedom | 4/4 | Skip, swipe, Android Back, and distinct setup choices are available. |
| 4 | Consistency and Standards | 3/4 | It follows the app's Material styling; previews are intentionally static. |
| 5 | Error Prevention | 3/4 | Setup choices are clear and do not make irreversible changes. |
| 6 | Recognition Rather Than Recall | 4/4 | Each page pairs a feature explanation with an in-app preview. |
| 7 | Flexibility and Efficiency of Use | 3/4 | Users can skip or choose manual entry/import, though they cannot jump between pages. |
| 8 | Aesthetic and Minimalist Design | 3/4 | The three-page sequence is focused; sample data needs clearer framing. |
| 9 | Help Users Recognize, Diagnose, and Recover from Errors | 3/4 | Users can go back or skip; no other recovery is needed for this walkthrough. |
| 10 | Help and Documentation | 3/4 | Feature guidance is concise and contextual. |
| **Total** | | **33/40 — Good (82.5%)** | |

## Design Specificity Verdict

**LLM assessment:** The flow is recognizably ClassCue: it explains Today/Week, on-device timetable import, reminders, and local backups. The main trust gap is that example class data can look like the user's own schedule.

**Deterministic scan:** Not applicable (native Android platform).

**Visual overlays:** Not applicable (native Android platform).

## Overall Impression

The onboarding is feature-based and easy to leave. Its strongest opportunity is to make example data unmistakably a preview and make multi-page progress explicit.

## What's Working

- The feature sequence is concrete and specific to ClassCue.
- Import and manual entry are both offered.
- Skip and Android Back keep the walkthrough optional.

## Cognitive Load

Low: 0 of 8 checklist failures. Each page has one focus, content is grouped, and the final screen offers only two setup choices.

## Priority Issues

1. **[P2] Example schedule data looks live.** “Data Structures” and “Starts in 45 min” appear without a visible sample label. A first-time user may think ClassCue already created a schedule. **Fix:** label the preview as example content.
2. **[P3] Progress has no visible step count.** The dots show movement, but users have to count them to know how many pages remain. **Fix:** show “Step X of 3” alongside them.

## Persona Red Flags

- **Jordan (First-Timer):** May mistake the preview for saved classes because the sample countdown and class details look live.
- **Casey (Mobile User):** May not know how much onboarding remains from the dots alone, though Skip is available.

## Minor Observations

- `onboarding_test.dart` still expects an older four-page flow and old button labels, so its assertions no longer match the current three-page onboarding.

## Questions to Consider

- Should the preview label say “Sample schedule” or “App preview”?
- Would a visible step count help first-time users feel oriented?
