---
target: ClassCue import review and scan flow
total_score: 31
max_score: 40
na_heuristics: 
p0_count: 0
p1_count: 2
target_identity: "file:C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\features\\schedule_import\\widgets\\import_review_widgets.dart"
target_fingerprint: "sha256:9537106fc2e4db6a83e7428f519c629339c7723600cb10c39f59e41a48ea3c5f"
target_path: "C:\\Users\\clarisse sibug\\Downloads\\ClassCue_redesign_phase29\\ClassCue_mobile\\lib\\features\\schedule_import\\widgets\\import_review_widgets.dart"
timestamp: 2026-10-21T10-38-26Z
slug: import-widgets-import-review-widgets-dart-a272ba32
---
# ClassCue Import Flow — Design Critique

**Scope:** Import scanning and review, focusing on `lib/features/schedule_import/widgets/import_review_widgets.dart` and its use in `lib/features/schedule_import/import_schedule_screen.dart`.

## Design Specificity

The flow is strongly specific to ClassCue. The local photo/PDF scan, four progress stages, class-day/time/room review, and import modes reflect the actual student timetable workflow. The scan card matches the supplied component guide well. The main opportunity is reducing the density of the review step, especially when several OCR and schedule warnings are present.

## Design Health Score

| # | Heuristic | Score | Key issue |
|---|---|---:|---|
| 1 | Visibility of system status | 3 | Strong scan progress; success and PDF stage transitions can be clearer. |
| 2 | Match between system and real world | 4 | Uses familiar class, day, time, room, and timetable language. |
| 3 | User control and freedom | 3 | Cancel, edit, add missed classes, and import modes are available; one mode becomes unusable without saved classes. |
| 4 | Consistency and standards | 3 | Scan and draft components follow the guide; the overall review screen stacks many patterns. |
| 5 | Error prevention | 4 | Flags OCR uncertainty, rooms, conflicts, and destructive replacements before saving. |
| 6 | Recognition rather than recall | 4 | Day, time, room, instructor, and issue state stay on each draft row. |
| 7 | Flexibility and efficiency | 3 | Supports photo/PDF, manual additions, and three import modes; the conflict check adds a step. |
| 8 | Aesthetic and minimalist design | 2 | The review page becomes dense when warnings and replacement options stack. |
| 9 | Error recovery | 3 | Users can edit, remove, cancel, and correct flagged rows; the post-import next step is unclear. |
| 10 | Help and documentation | 2 | Contextual tips exist, but mode consequences and scan limitations could be clearer at the decision point. |
| **Total** |  | **31/40** | **Good; the core flow is sound, with notable review-screen friction.** |

## Cognitive Load

**Moderate: 3 of 8 checklist failures.** Grouping is generally good, and each draft row keeps its own context. Hierarchy weakens when the summary, two stat cards, multiple warning banners, three import modes, draft list, and sticky actions appear together. Users also make several kinds of decisions on one screen, and replacement options are shown before they are needed.

## Overall Impression

The scanning panel gives useful, reassuring feedback and the draft cards make OCR mistakes actionable. The review screen is the weak link: it asks users to interpret warnings, choose a replacement policy, inspect rows, and decide whether to recheck conflicts in one long surface.

## What's Working

- The scan panel shows stage, percentage, a progress track, four stages, useful detail, and Cancel in the order specified by the HTML.
- Draft rows put day/time, class name, room/instructor, and specific issue text together; edit and remove actions are close to the affected row.
- The recommended Add mode and confirmation for replacement help prevent accidental schedule loss.

## Priority Issues

1. **[P1] Review content stacks too densely.** The review header and attention count are followed by room/issue statistics, up to three banners, the import-mode card, a long draft list, and a fixed two-button bar. This pushes the work itself down on a phone and repeats attention counts. Combine the summary and warnings into one compact review header, show only relevant warnings, and collapse replacement options behind a clearly named control.
2. **[P1] “Choose classes to replace” is available when there are no saved classes.** The option then shows an empty-state message while Import stays disabled because no replacement IDs can be selected. Hide or disable replacement modes when the saved schedule is empty, leaving Add to schedule as the only valid choice.
3. **[P2] Import success has no clear destination.** Saving clears the draft and selected file, then leaves the user at the file picker with only a transient snackbar. Offer a durable success state with “View schedule” and “Import another” actions.
4. **[P2] “Check conflicts” has an unclear role.** Conflicts are analyzed when scan results enter review and checked again before saving, yet a prominent manual check button is always present. Rename it “Refresh conflict check” and explain when it is needed, or rely on the save-time check and show its result beside the affected rows.
5. **[P2] PDF progress can skip a stage visually.** The PDF path sets the current stage to Reading text while the progress widget treats every earlier stage as complete. “Detecting grid” can therefore appear complete without ever being shown as active. Map PDF stages explicitly or use a PDF-specific stage sequence.

## Persona Red Flags

- **Jordan, first-time user:** If no schedule exists, “Choose classes to replace” leads to an empty selection and disabled Import button; they must infer that they should switch back to Add.
- **Casey, distracted mobile user:** Multiple warnings and summary blocks push draft rows down while the action bar stays pinned, forcing repeated scrolling between issues and actions.
- **Riley, deliberate stress tester:** PDF imports can show the wrong stage as complete; a multi-warning scan may also produce a long banner that is hard to scan.

## Minor Observations

- `ImportScanStage.failed` is assigned after a read failure, but the progress card is hidden once `_working` becomes false; the user sees a separate error message instead. Either remove the unused failed-stage state or keep a compact failure card with recovery actions.
- The scan's percentage and stage labels are live, but the changing detail text is outside the live region; screen-reader users may not hear what the current OCR operation is doing.

## Questions to Consider

- Could the review default to flagged rows and reveal clean rows on demand?
- Should successful import end with a direct “View schedule” action?
- Should conflict checking happen automatically, with a clear refresh option only when the saved schedule changes?
